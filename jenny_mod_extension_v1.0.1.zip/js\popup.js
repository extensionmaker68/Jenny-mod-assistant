document.addEventListener('DOMContentLoaded', () => {
    // Tab Switching Logic
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            const targetId = btn.getAttribute('data-tab');
            document.getElementById(targetId).classList.add('active');
        });
    });

    // Helper function to safely open links
    const openLink = (url) => {
        if (typeof chrome !== 'undefined' && chrome.tabs) {
            chrome.tabs.create({ url: url });
        } else {
            window.open(url, '_blank');
        }
    };

    // Action Buttons Links
    const WEBSITE_URL = 'https://downloadjennymod.org/';
    
    document.getElementById('btn-guide').addEventListener('click', () => {
        // Switch to install tab programmatically
        document.querySelector('.tab-btn[data-tab="install"]').click();
    });

    document.getElementById('btn-download').addEventListener('click', () => {
        openLink(WEBSITE_URL);
    });

    document.getElementById('btn-fixes').addEventListener('click', () => {
        // Switch to fixes tab programmatically
        document.querySelector('.tab-btn[data-tab="fixes"]').click();
    });

    document.getElementById('btn-website').addEventListener('click', () => {
        openLink(WEBSITE_URL);
    });

    // Footer brand click
    const brandLink = document.querySelector('.brand-text strong');
    if(brandLink) {
        brandLink.addEventListener('click', () => {
            openLink(WEBSITE_URL);
        });
    }

    // Copy Instructions Button
    document.getElementById('btn-copy-install').addEventListener('click', (e) => {
        const textToCopy = `Jenny Mod Installation Guide:
1. Install Java (Ensure Java 17+ for newer versions)
2. Install Forge Launcher (Match to 1.12.2)
3. Open Run (Win+R), type %appdata%\\.minecraft\\mods
4. Paste the downloaded Jenny Mod .jar file here
5. Launch Minecraft using the Forge profile.
Need more help? Visit https://downloadjennymod.org/`;

        navigator.clipboard.writeText(textToCopy).then(() => {
            const originalText = e.target.innerText;
            e.target.innerText = '✓ Copied to Clipboard!';
            setTimeout(() => {
                e.target.innerText = originalText;
            }, 2000);
        });
    });
});
