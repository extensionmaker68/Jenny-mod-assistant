# Jenny Mod Setup Assistant - Production Package

A professional, premium Chrome extension created for [downloadjennymod.org](https://downloadjennymod.org/). It serves as a branded utility dashboard for Minecraft players, providing safe installation guides, troubleshooting steps, and quick access to official resources.

## Package Structure
```text
/
├── manifest.json
├── popup.html
├── css/
│   └── popup.css
├── js/
│   └── popup.js
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
├── assets/
├── README.md
└── store_listing.md
```

## How to Test Locally
1. Open Google Chrome and go to `chrome://extensions/`.
2. Enable **Developer mode** (toggle in the top right).
3. Click **Load unpacked**.
4. Select the `jenny extension` folder (the unzipped folder containing this README).
5. Click the puzzle icon in Chrome to pin and open your new extension!
*Note: We have implemented an auto-fallback to `window.open` so the extension will safely test as both an unpacked extension and as a raw `file:///` in your browser.*

## Publishing Guide

This extension is built entirely on standard Web Technologies and complies strictly with **Manifest V3**. It asks for zero permissions, ensuring the fastest possible approval times on extension stores.

### Publishing to Chrome Web Store
1. Go to the [Chrome Developer Dashboard](https://chrome.google.com/webstore/devconsole/).
2. Click **New Item**.
3. Upload the `jenny_mod_extension_v1.0.1.zip` file.
4. Copy the text from `store_listing.md` into the Description box.
5. Upload the `128x128` icon in the Store Assets.
6. Submit for review! (Should take 24-48 hours since there are no permissions required).

### Publishing to Microsoft Edge Add-ons
1. Go to the [Edge Partner Center](https://partner.microsoft.com/en-us/dashboard/microsoftedge).
2. Create a new extension.
3. Upload the exact same `.zip` file. Edge fully supports Chrome's Manifest V3.
4. Paste the descriptions from `store_listing.md`.

### Publishing to Mozilla Firefox (AMO)
1. Go to the [Add-on Developer Hub](https://addons.mozilla.org/en-US/developers/).
2. Submit a new Add-on.
3. Upload the exact same `.zip` file. Firefox broadly supports standard Manifest V3 configurations.
4. Paste the descriptions.
